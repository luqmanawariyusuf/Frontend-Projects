document.getElementById("learnMoreBtn").addEventListener("click", function () {
  document.getElementById("features").scrollIntoView({ behavior: "smooth" });
});
